
/*
const netty = new brain.recurrent.LSTM();

netty.train([
  [1,2,3,4,5],
  [5,4,3,2,1],
]);

netty.run([1,2,3,4]);
netty.run([5,4,3,2]);
*/

async function getData(properties){

  //const response1 = await fetch("https://api.covid19api.com/total/dayone/country/"+properties);
  //const rona1 = await response1.json();

  var datat = [];
  for(var i = 0; i < 7; i++){

    //var totalCases = await rona1[rona1.length-(7-i)].Confirmed;
    datat.push({x:i, y:i});
  }

  console.log(datat);

  ronaChart.data.datasets[0].data = datat;
  ronaChart.update();
}

var myChart = document.getElementById('myChart').getContext('2d');

Chart.defaults.global.defaultFontColor= 'black';
Chart.defaults.global.defaultFontSize= 20;

pointy = new Image();
pointy.src = 'http://maps.google.com/mapfiles/kml/pal3/icon39.png';

pointy.width = 23;
pointy.height = 23;

var ronaChart = new Chart(myChart, {
  type:'scatter',
  data:{
  datasets: [{
     label: "Test",
     data: [
       {x: 0, y: 10},
       {x: 1, y: 10},
       {x: 2, y: 10},
       {x: 3, y: 10},
       {x: 4, y: 10},
       {x: 5, y: 10},
       {x: 6, y: 10},
       {x: 7, y: 10}
     ],
    pointBackgroundColor: 'green',
    pointStyle: pointy,
    pointHitRadius: 6,
    borderColor: 'black',
    showLine: true,
    borderColor: '#800000'
  }]
},
  options:{
    title:{
      display: true,
      text: 'Forecasted Number of Total COVID-19 Cases',
      fontSize: 30,
      fontColor: '#800000'
    },
    legend: {display: false},
    scales: {
      yAxes: [{
        scaleLabel: {
          display: true,
          labelString: 'Number of Cases',
          fontSize: 25,
          fontColor: '#800000',
          fontFamily: 'sans-serif',
          fontStyle: "bold"
        }
      }],
      xAxes: [{
        scaleLabel: {
          display: true,
          labelString: 'Days from Today',
          fontSize: 25,
          fontColor: '#800000',
          fontFamily: 'sans-serif',
          fontStyle: "bold"
        }
      }],
    }
  }
})

const net = new brain.NeuralNetwork();

net.train([
{ input: { r: 0.03, g: 0.7, b: 0.5 }, output: { black: 1 } },
{ input: { r: 0.16, g: 0.09, b: 0.2 }, output: { white: 1 } },
{ input: { r: 0.5, g: 0.5, b: 1.0 }, output: { white: 1 } },
]);

const output = net.run({ r: 1, g: 0.4, b: 0 });

console.log(output);

$(document).ready(function(){
  $("button").click(function(){
    var namee = document.getElementById('name').value;
    document.getElementById("name").value = "";
    console.log(namee);
    getData(namee);

  });
});
